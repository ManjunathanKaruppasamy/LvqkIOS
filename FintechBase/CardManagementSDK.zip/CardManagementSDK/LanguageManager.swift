//
//  LanguageManager.swift
//  DemoApp
//
//  Created by SENTHIL KUMAR on 20/01/23.
//  Copyright © 2023 Ranjith Ravichandran. All rights reserved.
//

import Foundation
import UIKit

var currentBundle : Bundle!

class LanguageManager {
    
    class func currentAppLanguage() -> String{
        let langArray = UserDefaults.standard.object(forKey: "AppLanguage") as? String
        return langArray ?? "en"
    }
    
    class func setLocalization(language : String){
        
        if let path = Bundle.main.path(forResource: language, ofType: "lproj"), let bundle = Bundle(path: path) {
            
            let attribute : UISemanticContentAttribute = language == "ar" ? .forceRightToLeft : .forceLeftToRight
            UIView.appearance().semanticContentAttribute = attribute
            
            let userdef = UserDefaults.standard
            userdef.set(language, forKey: "AppLanguage")
            userdef.synchronize()
            currentBundle = bundle
            
        } else {
            currentBundle = .main
        }
    }
    
}

