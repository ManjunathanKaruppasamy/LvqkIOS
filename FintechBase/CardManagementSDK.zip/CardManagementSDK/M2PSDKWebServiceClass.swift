//
//  M2PSDKWebServiceClass.swift
//  FintechBase
//
//  Created by SENTHIL KUMAR on 30/03/23.
//

import Foundation
@_implementationOnly import Alamofire
@_implementationOnly import ObjectMapper
import UIKit

class M2PWebServiceClass: NSObject {
    
    static let shared = M2PWebServiceClass()
    func callAPI<T: Mappable>(type: T.Type,
                              with api: String,
                              method: HTTPMethod,
                              parameter: Parameters?,
                              headers: HTTPHeaders?,
                              URL: String? = "",
                              completion: @escaping  (_ result: T?, _ error: String?, _ code: Int, _ headLessResponse: Any?) -> Void) {
        var param: Parameters = [:]
        var urlString = "https://sit-secure.yappay.in\(api)"
        var loginheaders: HTTPHeaders = [:]
        loginheaders["TENANT"] = TENANT.uppercased()
        loginheaders["Content-Type"] = "application/json"
        
        var parameterEncode: ParameterEncoding = JSONEncoding.default
        
        if method == .get {
            parameterEncode = URLEncoding.default
            if parameter != nil {
                var postString = ""
                for (key, value) in parameter ?? [:] {
                    postString += key + "=" + "\(value)" + "&"
                }
                if postString.hasSuffix("&") {
                    postString.removeLast()
                }
                urlString += "?" + postString
            }
        } else {
            param = parameter ?? [:]
        }
        
        print("urlString ... \(urlString)")
        print("parameter ... \(parameter ?? [:])")
        print("Headers ... \(loginheaders)")
        
        AF.request(urlString, method: method, parameters: param, encoding: parameterEncode, headers: loginheaders)
            .responseJSON { (response) in
                let code = response.response?.statusCode
                switch response.result {
                case .success(let json) :
                    print("====== Response Json ====== \n \(json)")
                    let responseValue = Mapper<T>().map(JSONObject: json)
                    completion(responseValue, nil, code ?? 0, nil)
                    break
                case .failure(let error):
                    print(error)
                    let error = error.localizedDescription
                    if error == "Unauthenticated." {
                        return
                    }
                    completion(nil, error, code ?? 0, nil)
                }
            }
    }
}
