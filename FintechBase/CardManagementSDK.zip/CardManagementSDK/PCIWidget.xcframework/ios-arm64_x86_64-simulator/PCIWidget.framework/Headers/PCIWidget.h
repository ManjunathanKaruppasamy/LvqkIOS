//
//  PCIWidget.h
//  PCIWidget
//
//  Created by Ranjith Ravichandran on 19/06/21.
//  Copyright © 2021 Ranjith Ravichandran. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PCIWidget.
FOUNDATION_EXPORT double PCIWidgetVersionNumber;

//! Project version string for PCIWidget.
FOUNDATION_EXPORT const unsigned char PCIWidgetVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PCIWidget/PublicHeader.h>


